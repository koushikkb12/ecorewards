import { Search, Star, ChevronRight } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export default function RewardsPage() {
  return (
    <div className="min-h-screen bg-[#f5f5f5]">
      {/* Header */}
      <header className="bg-[#1a1a1a] p-4">
        <div className="mx-auto max-w-7xl flex items-center justify-between">
          <nav className="flex items-center space-x-6">
            <Link href="/" className="text-white text-xl font-bold">
              Home
            </Link>
            <div className="relative">
              <input
                type="search"
                placeholder="Search rewards..."
                className="w-[300px] px-4 py-2 rounded-full bg-white/10 text-white placeholder:text-white/60 focus:outline-none focus:ring-2 focus:ring-green-500"
              />
              <Search className="absolute right-3 top-2.5 text-white/60 h-5 w-5" />
            </div>
            <Link href="/history" className="text-white">
              History
            </Link>
            <Link href="/rewards" className="text-white">
              Rewards
            </Link>
            <button className="px-4 py-1.5 bg-[#FFB300] rounded-full text-black font-medium">Rewards</button>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="mx-auto max-w-7xl p-6">
        <div className="bg-white rounded-2xl p-6 shadow-lg">
          {/* Title Section */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold mb-1">Rewards Center</h1>
              <p className="text-gray-500">Redeem your points for exciting rewards</p>
            </div>
            <div className="flex items-center space-x-2 bg-[#4CAF50]/10 px-4 py-2 rounded-xl">
              <span className="text-[#4CAF50] font-bold">350</span>
              <span className="text-gray-500">Available Points</span>
            </div>
          </div>

          {/* Rewards Categories */}
          <div className="grid grid-cols-4 gap-4 mb-8">
            <button className="flex items-center justify-center p-4 rounded-xl bg-[#4CAF50]/10 text-[#4CAF50] font-medium">
              All Rewards
            </button>
            <button className="flex items-center justify-center p-4 rounded-xl bg-gray-100 text-gray-600 font-medium">
              Gift Cards
            </button>
            <button className="flex items-center justify-center p-4 rounded-xl bg-gray-100 text-gray-600 font-medium">
              Eco Products
            </button>
            <button className="flex items-center justify-center p-4 rounded-xl bg-gray-100 text-gray-600 font-medium">
              Cash Rewards
            </button>
          </div>

          {/* Rewards Grid */}
          <div className="grid grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-gray-50 rounded-xl p-4 hover:shadow-md transition-shadow">
                <div className="aspect-square bg-white rounded-lg mb-4 flex items-center justify-center">
                  <div className="w-16 h-16 bg-[#4CAF50] rounded-full flex items-center justify-center">
                    <Image
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/UI-rflkHrNyo98ihElcy9SqOv6xSMmWFn.webp"
                      alt="Reward"
                      width={40}
                      height={40}
                      className="object-contain"
                    />
                  </div>
                </div>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-bold">Eco Reward #{i + 1}</h3>
                  <div className="flex items-center space-x-1">
                    <Star className="h-4 w-4 text-[#FFB300] fill-[#FFB300]" />
                    <span className="text-sm text-gray-500">4.5</span>
                  </div>
                </div>
                <p className="text-sm text-gray-500 mb-4">Redeem this reward for eco-friendly products or services</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="text-[#4CAF50] font-bold">100</span>
                    <span className="text-sm text-gray-500">points</span>
                  </div>
                  <button className="flex items-center space-x-1 text-sm text-[#4CAF50] font-medium">
                    <span>Redeem</span>
                    <ChevronRight className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Environmental Impact */}
          <div className="mt-12">
            <h2 className="text-2xl font-bold mb-6">Your Environmental Impact</h2>
            <div className="grid grid-cols-3 gap-6">
              <div className="bg-gray-50 rounded-xl p-4">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-10 h-10 bg-[#4CAF50] rounded-full flex items-center justify-center">
                    <Image
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/UI-rflkHrNyo98ihElcy9SqOv6xSMmWFn.webp"
                      alt="Icon"
                      width={24}
                      height={24}
                      className="object-contain"
                    />
                  </div>
                  <div>
                    <h3 className="font-bold">Total Waste Collected</h3>
                    <p className="text-sm text-gray-500">350 KG</p>
                  </div>
                </div>
                <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div className="h-full bg-[#4CAF50] w-[75%]" />
                </div>
              </div>
              <div className="bg-gray-50 rounded-xl p-4">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-10 h-10 bg-[#4CAF50] rounded-full flex items-center justify-center">
                    <Image
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/UI-rflkHrNyo98ihElcy9SqOv6xSMmWFn.webp"
                      alt="Icon"
                      width={24}
                      height={24}
                      className="object-contain"
                    />
                  </div>
                  <div>
                    <h3 className="font-bold">CO₂ Reduction</h3>
                    <p className="text-sm text-gray-500">25 Tons</p>
                  </div>
                </div>
                <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div className="h-full bg-[#4CAF50] w-[60%]" />
                </div>
              </div>
              <div className="bg-gray-50 rounded-xl p-4">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-10 h-10 bg-[#FFB300] rounded-full flex items-center justify-center">
                    <Image
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/UI-rflkHrNyo98ihElcy9SqOv6xSMmWFn.webp"
                      alt="Icon"
                      width={24}
                      height={24}
                      className="object-contain"
                    />
                  </div>
                  <div>
                    <h3 className="font-bold">Total Points Earned</h3>
                    <p className="text-sm text-gray-500">350 Points</p>
                  </div>
                </div>
                <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div className="h-full bg-[#FFB300] w-[85%]" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

