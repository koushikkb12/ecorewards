import { Search, Star } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export default function Home() {
  return (
    <div className="min-h-screen bg-[#f5f5f5]">
      {/* Header */}
      <header className="bg-[#1a1a1a] p-4">
        <div className="mx-auto max-w-7xl flex items-center justify-between">
          <nav className="flex items-center space-x-6">
            <Link href="/" className="text-white text-xl font-bold">
              Home
            </Link>
            <div className="relative">
              <input
                type="search"
                placeholder="Burnable Waste..."
                className="w-[300px] px-4 py-2 rounded-full bg-white/10 text-white placeholder:text-white/60 focus:outline-none focus:ring-2 focus:ring-green-500"
              />
              <Search className="absolute right-3 top-2.5 text-white/60 h-5 w-5" />
            </div>
            <Link href="/history" className="text-white">
              History
            </Link>
            <Link href="/rewards" className="text-white">
              Rewards
            </Link>
            <button className="px-4 py-1.5 bg-[#FFB300] rounded-full text-black font-medium">Rewards</button>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="mx-auto max-w-7xl p-6">
        <div className="bg-white rounded-2xl p-6 shadow-lg">
          {/* Title Section */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold mb-1">Burnable Waste</h1>
              <p className="text-gray-500">Burnable Waste Collection & Reward System</p>
            </div>
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/UI-rflkHrNyo98ihElcy9SqOv6xSMmWFn.webp"
              alt="Recycling Logo"
              width={60}
              height={60}
              className="object-contain"
            />
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-4 gap-4 mb-8">
            <div className="text-center">
              <div className="text-4xl font-bold">350</div>
              <div className="text-sm text-gray-500">Kg</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold">25</div>
              <div className="text-sm text-gray-500">Tons</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-[#4CAF50]">50</div>
              <div className="text-sm text-gray-500">Profile</div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-4 gap-4 mb-8">
            <button className="flex items-center justify-center p-4 rounded-xl bg-[#4CAF50]/10 text-[#4CAF50]">
              Home
            </button>
            <button className="flex items-center justify-center p-4 rounded-xl bg-[#4CAF50]/10 text-[#4CAF50]">
              History
            </button>
            <button className="flex items-center justify-center p-4 rounded-xl bg-[#4CAF50]/10 text-[#4CAF50]">
              Schedule
            </button>
            <button className="flex items-center justify-center p-4 rounded-xl bg-[#4CAF50]/10 text-[#4CAF50]">
              Profile
            </button>
          </div>

          {/* Progress Bar */}
          <div className="mb-8">
            <div className="h-4 bg-gray-100 rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-[#4CAF50] via-[#8BC34A] to-[#FFB300] w-[85%]" />
            </div>
            <div className="flex justify-between mt-2 text-sm text-gray-500">
              <span>0%</span>
              <span>85%</span>
            </div>
          </div>

          {/* Collection Cards */}
          <div className="grid grid-cols-2 gap-6 mb-8">
            <div className="bg-gray-50 rounded-xl p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold">TOTAL KG KG</h3>
                <div className="flex">
                  {[1, 2, 3, 4].map((star) => (
                    <Star key={star} className="h-5 w-5 text-[#FFB300] fill-[#FFB300]" />
                  ))}
                </div>
              </div>
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/UI-rflkHrNyo98ihElcy9SqOv6xSMmWFn.webp"
                alt="Garbage Truck"
                width={200}
                height={120}
                className="w-full object-contain"
              />
            </div>
            <div className="bg-gray-50 rounded-xl p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold">EARNED PICKUP</h3>
                <div className="flex">
                  {[1, 2, 3, 4].map((star) => (
                    <Star key={star} className="h-5 w-5 text-[#FFB300] fill-[#FFB300]" />
                  ))}
                </div>
              </div>
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/UI-rflkHrNyo98ihElcy9SqOv6xSMmWFn.webp"
                alt="Garbage Truck"
                width={200}
                height={120}
                className="w-full object-contain"
              />
            </div>
          </div>

          {/* Environmental Impact */}
          <div>
            <h2 className="text-2xl font-bold mb-4">ENVIRONMENTAL IMPACT</h2>
            <div className="bg-gray-50 rounded-xl p-4 mb-4">
              <p className="text-gray-600">Total Waste pickup vs. Earned Rewards</p>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-gray-50 rounded-xl p-4">
                <div className="flex justify-between items-center mb-2">
                  <div className="w-8 h-8 bg-[#4CAF50] rounded-full flex items-center justify-center">
                    <Image
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/UI-rflkHrNyo98ihElcy9SqOv6xSMmWFn.webp"
                      alt="Icon"
                      width={20}
                      height={20}
                      className="object-contain"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  {[40, 60, 80, 100].map((height, i) => (
                    <div key={i} className="h-4 bg-[#4CAF50] rounded" style={{ width: `${height}%` }} />
                  ))}
                </div>
              </div>
              <div className="bg-gray-50 rounded-xl p-4">
                <div className="flex justify-between items-center mb-2">
                  <div className="w-8 h-8 bg-[#4CAF50] rounded-full flex items-center justify-center">
                    <Image
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/UI-rflkHrNyo98ihElcy9SqOv6xSMmWFn.webp"
                      alt="Icon"
                      width={20}
                      height={20}
                      className="object-contain"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  {[30, 50, 70, 90].map((height, i) => (
                    <div key={i} className="h-4 bg-[#4CAF50] rounded" style={{ width: `${height}%` }} />
                  ))}
                </div>
              </div>
              <div className="bg-gray-50 rounded-xl p-4">
                <div className="flex justify-between items-center">
                  <h3 className="font-bold">Recurring Rewards</h3>
                  <div className="w-8 h-8 bg-[#FFB300] rounded-full" />
                </div>
                <div className="mt-4 text-2xl font-bold">₹20 ₹ ₹130</div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

