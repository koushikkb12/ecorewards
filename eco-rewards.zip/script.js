document.addEventListener("DOMContentLoaded", () => {
  const content = document.getElementById("content")
  const path = window.location.pathname

  switch (path) {
    case "/":
    case "/index.html":
      loadHome()
      break
    case "/history.html":
      loadHistory()
      break
    case "/rewards.html":
      loadRewards()
      break
    case "/schedule.html":
      loadSchedule()
      break
    case "/profile.html":
      loadProfile()
      break
    default:
      content.innerHTML = "<h1>Page not found</h1>"
  }
})

function loadHome() {
  const content = document.getElementById("content")
  content.innerHTML = `
        <h1>Dashboard</h1>
        <div class="dashboard-stats">
            <div class="stat-box">
                <h2>Total Waste Contributed</h2>
                <p>-- KG Collected</p>
            </div>
            <div class="stat-box">
                <h2>Total Rewards Earned</h2>
                <p>-- Points / $--</p>
            </div>
        </div>
        <div class="stat-box">
            <h2>Next Scheduled Pickup</h2>
            <p>Date: --</p>
            <p>Time: --</p>
        </div>
        <h2>Environmental Impact</h2>
        <div class="progress-bar">
            <div class="progress" style="width: 0%;"></div>
        </div>
        <p>You helped reduce CO₂ emissions by -- kg</p>
        <button onclick="schedulePickup()">Schedule Pickup</button>
        <button onclick="viewHistory()">View Past Contributions</button>
        <button onclick="redeemRewards()">Redeem Rewards</button>
    `
}

function loadHistory() {
  const content = document.getElementById("content")
  content.innerHTML = `
        <h1>Contribution History</h1>
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Waste Contributed (kg)</th>
                    <th>Reward Points</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <!-- Add rows dynamically here -->
            </tbody>
        </table>
    `
}

function loadRewards() {
  const content = document.getElementById("content")
  content.innerHTML = `
        <h1>Rewards</h1>
        <div class="stat-box">
            <h2>Total Rewards Earned</h2>
            <p>-- Points</p>
        </div>
        <h2>Rewards Catalog</h2>
        <div class="rewards-catalog">
            <!-- Add reward items dynamically here -->
        </div>
        <button onclick="cashOut()">Cash Out</button>
    `
}

function loadSchedule() {
  const content = document.getElementById("content")
  content.innerHTML = `
        <h1>Pickup Schedule</h1>
        <div id="calendar">
            <!-- Add calendar or list view here -->
        </div>
        <button onclick="requestReschedule()">Request Reschedule</button>
        <h2>Pickup Guidelines</h2>
        <ul>
            <!-- Add guidelines here -->
        </ul>
    `
}

function loadProfile() {
  const content = document.getElementById("content")
  content.innerHTML = `
        <h1>Profile</h1>
        <div class="profile-info">
            <div>Name: --</div>
            <div>Address: --</div>
            <div>Contact Info: --</div>
            <div>Total Waste Contributed: -- KG</div>
            <div>Total Rewards Earned: -- Points</div>
        </div>
        <button onclick="editProfile()">Edit Profile</button>
        <button onclick="logout()">Logout</button>
    `
}

function schedulePickup() {
  alert("Schedule Pickup functionality not implemented")
}

function viewHistory() {
  window.location.href = "history.html"
}

function redeemRewards() {
  window.location.href = "rewards.html"
}

function cashOut() {
  alert("Cash Out functionality not implemented")
}

function requestReschedule() {
  alert("Request Reschedule functionality not implemented")
}

function editProfile() {
  alert("Edit Profile functionality not implemented")
}

function logout() {
  alert("Logout functionality not implemented")
}

